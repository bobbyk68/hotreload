
package com.example.drools;

import org.drools.compiler.compiler.DSLTokenizedMappingFile;
import org.drools.compiler.lang.dsl.DefaultExpander;
import org.kie.api.KieServices;
import org.kie.api.builder.*;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class DroolsService {

    private KieContainer kieContainer;

    @PostConstruct
    public void init() {
        reloadRules();
    }

    public void reloadRules() {
        try {
            Path dslPath = Path.of("src/main/resources/rules/sample.dsl");
            Path dslrPath = Path.of("src/main/resources/rules/sample.dslr");

            DSLTokenizedMappingFile dsl = new DSLTokenizedMappingFile();
            dsl.parseAndLoad(new InputStreamReader(Files.newInputStream(dslPath)));

            DefaultExpander expander = new DefaultExpander();
            expander.addDSLMapping(dsl.getMapping());

            String dslrContent = Files.readString(dslrPath);
            String drl = expander.expand(dslrContent);

            KieServices ks = KieServices.Factory.get();
            KieFileSystem kfs = ks.newKieFileSystem();
            kfs.write("src/main/resources/rules/sample.drl", drl);

            KieBuilder kb = ks.newKieBuilder(kfs).buildAll();
            Results results = kb.getResults();
            if (results.hasMessages(Message.Level.ERROR)) {
                throw new RuntimeException("Build Errors:\n" + results.getMessages());
            }

            kieContainer = ks.newKieContainer(ks.getRepository().getDefaultReleaseId());

        } catch (Exception e) {
            throw new RuntimeException("Rule reload failed", e);
        }
    }

    public void executeRules() {
        KieSession kieSession = kieContainer.newKieSession();
        kieSession.insert(new Message("World"));
        kieSession.fireAllRules();
        kieSession.dispose();
    }
}
